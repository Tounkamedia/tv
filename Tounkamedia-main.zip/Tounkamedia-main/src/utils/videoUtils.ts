
export const getEmbedUrl = (url: string): string => {
  try {
    // YouTube
    if (url.includes('youtube.com') || url.includes('youtu.be')) {
      const videoId = url.includes('youtube.com') 
        ? url.split('v=')[1]?.split('&')[0]
        : url.split('youtu.be/')[1]?.split('?')[0];
      if (videoId) {
        return `https://www.youtube.com/embed/${videoId}`;
      }
    }

    // Dailymotion
    if (url.includes('dailymotion.com') || url.includes('dai.ly')) {
      const videoId = url.includes('dailymotion.com') 
        ? url.split('/video/')[1]?.split('?')[0]
        : url.split('dai.ly/')[1]?.split('?')[0];
      if (videoId) {
        return `https://www.dailymotion.com/embed/video/${videoId}`;
      }
    }

    // Facebook
    if (url.includes('facebook.com')) {
      const encodedUrl = encodeURIComponent(url);
      return `https://www.facebook.com/plugins/video.php?href=${encodedUrl}&show_text=false&appId=`;
    }

    // Si l'URL n'est pas reconnue, on la retourne telle quelle
    console.log('URL non reconnue:', url);
    return url;
  } catch (error) {
    console.error('Erreur lors du traitement de l\'URL:', error);
    return url;
  }
};
