
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Video from "./pages/Video";
import VideoPlayer from "./pages/VideoPlayer";
import Podcasts from "./pages/Podcasts";
import PodcastPlayer from "./pages/PodcastPlayer";
import Radio from "./pages/Radio";
import Direct from "./pages/Direct";
import DirectPlayer from "./pages/DirectPlayer";
import Movies from "./pages/Movies";
import Shopping from "./pages/Shopping";
import Search from "./pages/Search";
import Settings from "./pages/Settings";
import NotFound from "./pages/NotFound";

const App = () => (
  <TooltipProvider>
    <Toaster />
    <Sonner />
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Index />} />
        <Route path="/videos" element={<Video />} />
        <Route path="/videos/:id" element={<VideoPlayer />} />
        <Route path="/podcasts" element={<Podcasts />} />
        <Route path="/podcasts/:id" element={<PodcastPlayer />} />
        <Route path="/radio" element={<Radio />} />
        <Route path="/direct" element={<Direct />} />
        <Route path="/direct/player" element={<DirectPlayer />} />
        <Route path="/movies" element={<Movies />} />
        <Route path="/shopping" element={<Shopping />} />
        <Route path="/search" element={<Search />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </BrowserRouter>
  </TooltipProvider>
);

export default App;
