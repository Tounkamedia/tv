
import { create } from 'zustand';

interface PlayerState {
  currentMedia: {
    title: string;
    type: 'radio' | 'video' | 'podcast';
    url: string;
    coverImage?: string;
  } | null;
  isPlaying: boolean;
  isMinimized: boolean;
  audioInstance: HTMLAudioElement | null;
  setCurrentMedia: (media: PlayerState['currentMedia']) => void;
  setIsPlaying: (isPlaying: boolean) => void;
  setIsMinimized: (isMinimized: boolean) => void;
  setAudioInstance: (audio: HTMLAudioElement | null) => void;
  clearMedia: () => void;
  stopAllMedia: () => void;
}

export const usePlayerStore = create<PlayerState>((set, get) => ({
  currentMedia: null,
  isPlaying: false,
  isMinimized: true,
  audioInstance: null,
  setCurrentMedia: (media) => set({ currentMedia: media }),
  setIsPlaying: (isPlaying) => set({ isPlaying }),
  setIsMinimized: (isMinimized) => set({ isMinimized }),
  setAudioInstance: (audio) => set({ audioInstance: audio }),
  clearMedia: () => set({ 
    currentMedia: null, 
    isPlaying: false, 
    isMinimized: true,
    audioInstance: null 
  }),
  stopAllMedia: () => {
    const { audioInstance } = get();
    if (audioInstance) {
      audioInstance.pause();
      audioInstance.src = '';
    }
    set({
      isPlaying: false,
      audioInstance: null
    });
  }
}));
