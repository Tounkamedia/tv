
import { useState, useEffect } from 'react';
import { Play, Pause, Volume2 } from 'lucide-react';
import { usePlayerStore } from '../store/playerStore';
import LoadingSpinner from './LoadingSpinner';

interface RadioStationProps {
  station: {
    name: string;
    logo: string;
    genre: string;
    streamUrl: string;
  };
  isPlaying: boolean;
  isLoading: boolean;
  onTogglePlay: () => void;
}

const RadioStation = ({ 
  station, 
  isPlaying, 
  isLoading, 
  onTogglePlay 
}: RadioStationProps) => {
  const [showSpinner, setShowSpinner] = useState(false);
  
  // Lorsque isLoading change à true, on affiche le spinner
  useEffect(() => {
    if (isLoading) {
      setShowSpinner(true);
    }
  }, [isLoading]);

  // Lorsque isPlaying change à true, on laisse le spinner affiché pendant 3 secondes
  useEffect(() => {
    if (isPlaying) {
      const timer = setTimeout(() => {
        setShowSpinner(false);
      }, 3000);
      
      return () => clearTimeout(timer);
    }
  }, [isPlaying]);

  return (
    <div className="relative overflow-hidden rounded-xl bg-[#1a1a1a] shadow-lg transition-all">
      <div className="flex items-center p-4 gap-4">
        <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
          <img 
            src={station.logo} 
            alt={station.name}
            className="w-full h-full object-cover"
          />
        </div>
        <div className="flex-1">
          <h3 className="font-semibold text-white">{station.name}</h3>
          <p className="text-sm text-white/70">{station.genre || 'Radio'}</p>
        </div>
        <button
          onClick={onTogglePlay}
          disabled={isLoading}
          className="w-12 h-12 rounded-full bg-primary text-white flex items-center justify-center hover:bg-primary/90 transition-colors disabled:opacity-70"
        >
          {showSpinner ? (
            <LoadingSpinner className="w-6 h-6" />
          ) : isPlaying ? (
            <Pause className="w-6 h-6" />
          ) : (
            <Play className="w-6 h-6" />
          )}
        </button>
      </div>
      {isPlaying && (
        <div className="p-4 border-t border-white/10 flex items-center gap-3">
          <Volume2 className="w-5 h-5 text-primary" />
          <div className="text-sm text-white">En direct</div>
        </div>
      )}
    </div>
  );
};

export default RadioStation;
