
import { LucideIcon } from 'lucide-react';
import { motion } from 'framer-motion';
import { useTheme } from '../providers/ThemeProvider';

interface AppIconProps {
  icon: LucideIcon;
  label: string;
  color: string;
  onClick?: () => void;
  showBadge?: boolean;
  isLive?: boolean;
}

export function AppIcon({ icon: Icon, label, color, onClick, showBadge, isLive }: AppIconProps) {
  const { theme } = useTheme();
  const isDark = theme === 'dark';
  
  return (
    <motion.button 
      onClick={onClick} 
      className="app-icon"
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
    >
      <div className="relative">
        <div 
          className="w-24 h-24 flex items-center justify-center rounded-2xl transition-all duration-300"
          style={{ 
            backgroundColor: color,
            boxShadow: isDark ? "0 4px 8px rgba(0, 0, 0, 0.3)" : "0 4px 8px rgba(0, 0, 0, 0.1)"
          }}
        >
          <Icon 
            className="w-12 h-12" 
            style={{ color: "#FFFFFF" }}
          />
        </div>
        {showBadge && (
          <motion.div 
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"
          />
        )}
        {isLive && (
          <div className="absolute -top-1 -right-1 flex items-center justify-center">
            <motion.div 
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ repeat: Infinity, duration: 2 }}
              className="w-3 h-3 bg-green-500 rounded-full"
            />
            <div className="absolute w-3 h-3 bg-green-500 rounded-full animate-ping" />
          </div>
        )}
      </div>
      <span className="text-sm text-center font-medium mt-2">{label}</span>
    </motion.button>
  );
}
