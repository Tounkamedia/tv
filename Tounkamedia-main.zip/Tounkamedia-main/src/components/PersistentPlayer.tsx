
import React from 'react';
import { Volume2, Pause, Play, X } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';

interface PersistentPlayerProps {
  title: string;
  isPlaying: boolean;
  isMinimized?: boolean;
  type: 'radio' | 'video' | 'podcast';
  coverImage?: string;
  onTogglePlay: () => void;
  onClose?: () => void;
  routePath?: string;
}

const PersistentPlayer = ({
  title,
  isPlaying,
  isMinimized = true,
  type,
  coverImage,
  onTogglePlay,
  onClose,
  routePath
}: PersistentPlayerProps) => {
  const navigate = useNavigate();
  const location = useLocation();

  // Ne pas afficher sur la page de lecture des podcasts ou pour les vidéos
  if (type === 'video' || location.pathname.startsWith('/podcasts/')) {
    return null;
  }

  return (
    <div className="fixed bottom-16 left-0 right-0 bg-background border-t p-4 animate-slide-up z-50">
      <div className="max-w-2xl mx-auto flex items-center justify-between gap-4">
        <div className="flex items-center gap-3 flex-1 min-w-0">
          {coverImage && (
            <div className="w-12 h-12 rounded overflow-hidden flex-shrink-0">
              <img src={coverImage} alt={title} className="w-full h-full object-cover" />
            </div>
          )}
          <div className="flex-1 min-w-0">
            <h4 className="font-medium truncate text-sm">{title}</h4>
            <p className="text-xs text-muted-foreground capitalize">{type}</p>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <button
            onClick={onTogglePlay}
            className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center hover:bg-primary/90 transition-colors"
          >
            {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
          </button>
          
          {routePath && (
            <button
              onClick={() => navigate(routePath)}
              className="text-sm text-primary hover:text-primary/80 transition-colors"
            >
              Retour
            </button>
          )}

          {onClose && (
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-muted flex items-center justify-center hover:bg-muted/80 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default PersistentPlayer;
