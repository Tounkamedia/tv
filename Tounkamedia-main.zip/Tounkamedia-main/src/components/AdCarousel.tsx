
import { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const ads = [
  {
    image: "https://i.ibb.co/39npHDMy/SS.jpg",
  },
  {
    image: "https://i.ibb.co/mrpxFVXP/aaq.jpg",
  },
  {
    image: "https://i.ibb.co/3YdxjRD7/lqkq.jpg",
  },
];

export function AdCarousel() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % ads.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const loadImages = async () => {
      const imagePromises = ads.map(ad => {
        return new Promise((resolve) => {
          const img = new Image();
          img.src = ad.image;
          img.onload = () => resolve(true);
        });
      });
      await Promise.all(imagePromises);
      setIsLoading(false);
    };
    loadImages();
  }, []);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % ads.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + ads.length) % ads.length);
  };

  if (isLoading) {
    return (
      <div className="mt-8 space-y-4">
        <div className="carousel group animate-pulse">
          <div className="w-full h-[180px] bg-muted rounded-2xl"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="mt-8 space-y-4">
      <div className="carousel group">
        <div
          className="flex transition-transform duration-500 ease-out h-full"
          style={{ transform: `translateX(-${currentSlide * 100}%)` }}
        >
          {ads.map((ad, index) => (
            <div
              key={index}
              className="w-full h-full flex-shrink-0 relative"
            >
              <img
                src={ad.image}
                alt=""
                className="w-full h-full object-cover rounded-2xl"
              />
            </div>
          ))}
        </div>
        <button
          onClick={prevSlide}
          className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 flex items-center justify-center rounded-full bg-white/80 opacity-0 group-hover:opacity-100 transition-opacity duration-200 hover:scale-110 transition-transform"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <button
          onClick={nextSlide}
          className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 flex items-center justify-center rounded-full bg-white/80 opacity-0 group-hover:opacity-100 transition-opacity duration-200 hover:scale-110 transition-transform"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
        <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2">
          {ads.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-2 h-2 rounded-full transition-all ${
                currentSlide === index 
                  ? 'bg-white w-4' 
                  : 'bg-white/50'
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
