
import { Search, Settings } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

export function NavBar() {
  const navigate = useNavigate();
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav 
      className="fixed bottom-0 left-0 right-0 flex justify-center items-center px-4 py-2 z-50 bg-background/80 backdrop-blur-lg border-t"
    >
      <div className="max-w-md w-full flex justify-between items-center px-4 py-2">
        <motion.button 
          className={cn(
            "p-1.5 rounded-lg transition-colors",
            isActive('/settings') 
              ? "bg-card text-foreground" 
              : "text-muted-foreground hover:text-foreground hover:bg-muted"
          )}
          onClick={() => navigate('/settings')}
          whileTap={{ scale: 0.9 }}
          animate={isActive('/settings') ? { scale: [1, 1.05, 1] } : {}}
          transition={isActive('/settings') ? { repeat: 0, duration: 0.3 } : {}}
        >
          <Settings className="w-9 h-9" />
        </motion.button>
        
        <motion.button 
          className={cn(
            "p-1.5 rounded-lg transition-colors",
            isActive('/') 
              ? "bg-card text-foreground" 
              : "text-muted-foreground hover:text-foreground hover:bg-muted"
          )}
          onClick={() => navigate('/')}
          whileTap={{ scale: 0.9 }}
          animate={isActive('/') ? { scale: [1, 1.05, 1] } : {}}
          transition={isActive('/') ? { repeat: 0, duration: 0.3 } : {}}
        >
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 708.7 708.7" className="w-9 h-9">
            <g>
              <g>
                <g>
                  <path fill="#00A94F" d="M443.3,74.5c-29.1-37.7-82.1-53.3-125.9-37.1c-32.2,11.9-56.2,36-71.5,71.5c-14.2,33.1-14.6,69.3-1.3,110.7 c12.9,40.1,34.6,74.7,55.7,106.7c0.7,1,1.3,2.3,2.1,3.9c0.5,1,1,2.1,1.6,3.2l9.3-4.9l33.6,0.3l6,9l7.3-8.9l34.8,0.3l9.3,5.1 c0.8-1.5,1.6-2.9,2.2-4.1c1.2-2.2,2.1-3.9,3.1-5.4c2.4-3.8,4.9-7.7,7.4-11.5c4.2-6.5,8.6-13.3,12.7-20.2 c15.3-25.6,33.8-60.3,40.9-100.9C478.6,147.8,469.3,108.2,443.3,74.5z M311.5,120.6c5.3-9.2,12.2-16.5,20.5-21.9 c7.6-4.9,15.6-7.4,23.5-7.4c9.6,0,18.9,3.6,27.1,10.7c16.9,14.8,25.6,34.9,27.6,63.3c1.5,22.8-6.3,44.4-15,64.4 c-11.6,26.6-26.7,50.9-40.9,71.9c-4.1-6.1-8-12-11.8-17.9c-15.2-24.2-31.8-53.5-39.8-87C295.8,167.6,298.7,142.7,311.5,120.6z"/>
                </g>
                <g>
                  <path fill="#FFFFFF" d="M291.3,677.1l26.9-358.2h68l30.8,358.2H291.3z"/>
                  <polygon fill="#FF0150" points="125.3,392.6 125.3,304.2 354.7,318.9 583.1,304.2 583.1,392.6 354.7,381 "/>
                </g>
              </g>
            </g>
          </svg>
        </motion.button>
        
        <motion.button 
          className={cn(
            "p-1.5 rounded-lg transition-colors",
            isActive('/search') 
              ? "bg-card text-foreground" 
              : "text-muted-foreground hover:text-foreground hover:bg-muted"
          )}
          onClick={() => navigate('/search')}
          whileTap={{ scale: 0.9 }}
          animate={isActive('/search') ? { scale: [1, 1.05, 1] } : {}}
          transition={isActive('/search') ? { repeat: 0, duration: 0.3 } : {}}
        >
          <Search className="w-9 h-9" />
        </motion.button>
      </div>
    </nav>
  );
}
