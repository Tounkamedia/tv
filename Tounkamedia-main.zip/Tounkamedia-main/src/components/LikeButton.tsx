
import { useState } from 'react';
import { Heart } from 'lucide-react';
import { useLikes } from '../hooks/useLikes';
import { motion } from 'framer-motion';

interface LikeButtonProps {
  contentType: 'video' | 'podcast' | 'direct';
  contentId: string;
}

export function LikeButton({ contentType, contentId }: LikeButtonProps) {
  const { isLiked, toggleLike } = useLikes();
  const [liked, setLiked] = useState(isLiked(contentType, contentId));

  const handleLike = () => {
    const newLikedState = toggleLike(contentType, contentId);
    setLiked(newLikedState);
  };

  return (
    <motion.button
      onClick={handleLike}
      className="flex items-center justify-center"
      whileTap={{ scale: 0.9 }}
      initial={{ scale: 1 }}
    >
      <motion.div
        animate={{ scale: liked ? [1, 1.3, 1] : 1 }}
        transition={{ duration: 0.3 }}
      >
        <Heart
          className={`w-6 h-6 ${liked ? 'fill-red-500 text-red-500' : 'text-gray-500'}`}
        />
      </motion.div>
    </motion.button>
  );
}
