
import { useState } from 'react';
import { Search as SearchIcon, Video, Radio, Tv, ShoppingBag, Headphones } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { NavBar } from '../components/NavBar';
import { useQuery } from '@tanstack/react-query';
import { getVideos, getRadios, getDirectChannels, getPodcasts } from '../services/googleSheets';
import { useTheme } from '../providers/ThemeProvider';

const categories = [
  { name: "Vidéos", icon: Video, route: "/videos" },
  { name: "Podcasts", icon: Headphones, route: "/podcasts" },
  { name: "Radio", icon: Radio, route: "/radio" },
  { name: "Direct", icon: Tv, route: "/direct" },
  { name: "Shopping", icon: ShoppingBag, route: "/shopping" }
];

const SearchPage = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const navigate = useNavigate();
  const { theme } = useTheme();
  const isDark = theme === 'dark';

  const { data: videos } = useQuery({
    queryKey: ['videos'],
    queryFn: getVideos,
    enabled: searchQuery.length > 0
  });

  const { data: radios } = useQuery({
    queryKey: ['radios'],
    queryFn: getRadios,
    enabled: searchQuery.length > 0
  });

  const { data: channels } = useQuery({
    queryKey: ['direct'],
    queryFn: getDirectChannels,
    enabled: searchQuery.length > 0
  });

  const { data: podcasts } = useQuery({
    queryKey: ['podcasts'],
    queryFn: getPodcasts,
    enabled: searchQuery.length > 0
  });

  const getSearchResults = () => {
    if (!searchQuery) return [];

    const searchLower = searchQuery.toLowerCase();
    const results = [];

    // Recherche dans les vidéos
    videos?.forEach(video => {
      if (video.title.toLowerCase().includes(searchLower)) {
        results.push({
          id: `video-${video.title}`,
          title: video.title,
          type: 'video',
          image: video.thumbnailUrl,
          route: '/videos'
        });
      }
    });

    // Recherche dans les radios
    radios?.forEach(radio => {
      if (radio.name.toLowerCase().includes(searchLower)) {
        results.push({
          id: `radio-${radio.name}`,
          title: radio.name,
          type: 'radio',
          image: radio.logo,
          route: '/radio'
        });
      }
    });

    // Recherche dans les chaînes en direct
    channels?.forEach(channel => {
      if (channel.title.toLowerCase().includes(searchLower)) {
        results.push({
          id: `direct-${channel.title}`,
          title: channel.title,
          type: 'direct',
          image: channel.logo,
          route: '/direct'
        });
      }
    });

    // Recherche dans les podcasts
    podcasts?.forEach(podcast => {
      if (podcast.title.toLowerCase().includes(searchLower)) {
        results.push({
          id: `podcast-${podcast.title}`,
          title: podcast.title,
          type: 'podcast',
          image: podcast.cover,
          route: '/podcasts'
        });
      }
    });

    return results;
  };

  const results = getSearchResults();

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="max-w-2xl mx-auto p-4">
        <div className="sticky top-0 bg-background pt-4 pb-2 z-10">
          <div className={`relative ${isDark ? 'glass-effect glass-effect-dark' : 'glass-effect glass-effect-light'} rounded-full`}>
            <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-6 h-6 text-muted-foreground" />
            <input
              type="text"
              placeholder="Rechercher..."
              className="w-full pl-10 pr-4 py-2.5 rounded-full bg-transparent focus:outline-none"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        {!searchQuery && (
          <div className="mt-6">
            <h2 className="text-lg font-medium mb-4">Catégories</h2>
            <div className="grid grid-cols-2 gap-4 animate-fade-in">
              {categories.map((category) => (
                <Link
                  key={category.name}
                  to={category.route}
                  className={`flex items-center gap-3 p-4 rounded-lg shadow-sm hover:shadow-md transition-all hover:scale-105 ${isDark ? 'glass-effect glass-effect-dark' : 'glass-effect glass-effect-light'}`}
                >
                  <category.icon className="w-8 h-8 text-primary" />
                  <span className="font-medium">{category.name}</span>
                </Link>
              ))}
            </div>
          </div>
        )}

        {searchQuery && (
          <div className="mt-6 animate-fade-in">
            <h2 className="text-lg font-medium mb-4">Résultats ({results.length})</h2>
            {results.length > 0 ? (
              <div className="grid gap-4">
                {results.map((result) => (
                  <button
                    key={result.id}
                    onClick={() => navigate(result.route)}
                    className={`flex items-center gap-4 p-4 rounded-lg hover:bg-muted/50 transition-colors ${isDark ? 'glass-effect glass-effect-dark' : 'glass-effect glass-effect-light'}`}
                  >
                    <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
                      <img 
                        src={result.image} 
                        alt={result.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1 text-left">
                      <h3 className="font-medium line-clamp-2">{result.title}</h3>
                      <p className="text-sm text-muted-foreground capitalize mt-1">{result.type}</p>
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <p className="text-center text-muted-foreground py-8">
                Aucun résultat trouvé pour "{searchQuery}"
              </p>
            )}
          </div>
        )}
      </div>
      <NavBar />
    </div>
  );
};

export default SearchPage;
