
import { useState, useEffect } from 'react';
import { ChevronLeft, Search, ChevronDown } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { getRadios } from '../services/googleSheets';
import RadioStation from '../components/RadioStation';
import { usePlayerStore } from '../store/playerStore';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

const RadioPage = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [playingStationId, setPlayingStationId] = useState<string | null>(null);
  const [loadingStationId, setLoadingStationId] = useState<string | null>(null);
  const [displayCount, setDisplayCount] = useState(20);
  const { 
    setCurrentMedia, 
    currentMedia, 
    isPlaying, 
    setIsPlaying, 
    audioInstance, 
    setAudioInstance,
    stopAllMedia
  } = usePlayerStore();

  const { data: radios, isLoading, error } = useQuery({
    queryKey: ['radios'],
    queryFn: getRadios
  });

  // Tri des radios par ordre alphabétique
  const sortedRadios = radios?.slice().sort((a, b) => 
    a.name.localeCompare(b.name)
  );

  const filteredRadios = sortedRadios?.filter(radio =>
    radio.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    radio.genre?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const visibleRadios = filteredRadios?.slice(0, displayCount);
  const hasMoreRadios = filteredRadios && displayCount < filteredRadios.length;

  const loadMore = () => {
    setDisplayCount(prev => prev + 30);
  };

  useEffect(() => {
    if (currentMedia?.type !== 'radio') {
      setPlayingStationId(null);
    }
  }, [currentMedia]);

  const handleTogglePlay = (station: any) => {
    const stationId = station.name;
    
    if (playingStationId === stationId && isPlaying) {
      // Arrêter la station en cours
      setIsPlaying(false);
      if (audioInstance) {
        audioInstance.pause();
      }
      setCurrentMedia(null);
      setPlayingStationId(null);
      return;
    }
    
    // Arrêter tous les médias en cours avant de jouer une nouvelle station
    stopAllMedia();
    
    // Jouer une nouvelle station
    setLoadingStationId(stationId);
    
    // Créer une nouvelle instance audio
    const audio = new Audio(station.streamUrl);
    
    // Configurer les événements audio
    audio.addEventListener('canplay', () => {
      console.log("Radio prête à jouer:", station.name);
      setTimeout(() => {
        setLoadingStationId(null);
      }, 1000);
    });
    
    audio.addEventListener('error', (e) => {
      console.error("Erreur de chargement de la radio:", e);
      toast.error(`Impossible de charger la radio ${station.name}`);
      setLoadingStationId(null);
      setPlayingStationId(null);
      setIsPlaying(false);
    });
    
    // Commencer à charger l'audio
    audio.load();
    
    // Essayer de jouer l'audio
    audio.play().then(() => {
      console.log("Radio lecture commencée:", station.name);
      
      setCurrentMedia({
        title: station.name,
        type: 'radio',
        url: station.streamUrl,
        coverImage: station.logo
      });
      
      setAudioInstance(audio);
      setIsPlaying(true);
      setPlayingStationId(stationId);
      
      // Notification que la radio joue
      toast.success(`Radio ${station.name} en cours de lecture`);
      
    }).catch(err => {
      console.error("Erreur lors de la lecture:", err);
      setLoadingStationId(null);
      
      // Message d'erreur si la lecture échoue
      toast.error("Impossible de lire cette radio. Veuillez réessayer.");
    });
  };

  if (isLoading) {
    return <div className="min-h-screen bg-background p-4">Chargement...</div>;
  }

  if (error) {
    return <div className="min-h-screen bg-background p-4">Erreur de chargement des radios</div>;
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="max-w-2xl mx-auto p-4">
        <header className="flex items-center gap-4 mb-6">
          <Link to="/" className="text-muted-foreground hover:text-foreground transition-colors">
            <ChevronLeft className="w-6 h-6" />
          </Link>
          <h1 className="text-xl font-semibold">Radio</h1>
        </header>

        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
          <Input
            type="text"
            placeholder="Rechercher une radio..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        <div className="grid gap-4 animate-fade-in">
          {visibleRadios?.map((station) => (
            <RadioStation
              key={station.name}
              station={station}
              isPlaying={playingStationId === station.name && isPlaying}
              isLoading={loadingStationId === station.name}
              onTogglePlay={() => handleTogglePlay(station)}
            />
          ))}
        </div>

        {hasMoreRadios && (
          <div className="mt-8 flex justify-center">
            <Button 
              variant="outline" 
              className="gap-2 px-8" 
              onClick={loadMore}
            >
              Voir plus
              <ChevronDown className="w-4 h-4" />
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default RadioPage;
