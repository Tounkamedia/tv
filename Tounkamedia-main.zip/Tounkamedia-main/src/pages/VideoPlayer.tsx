
import React, { useEffect } from 'react';
import { ChevronLeft } from 'lucide-react';
import { useLocation, useNavigate } from 'react-router-dom';
import { usePlayerStore } from '../store/playerStore';
import { getEmbedUrl } from '../utils/videoUtils';
import { LikeButton } from '../components/LikeButton';

const VideoPlayer = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { video } = location.state || {};
  const { setCurrentMedia } = usePlayerStore();

  useEffect(() => {
    if (!video) {
      navigate('/video');
      return;
    }

    const embedUrl = getEmbedUrl(video.videoUrl);
    setCurrentMedia({
      title: video.title,
      type: 'video',
      url: embedUrl,
      coverImage: video.thumbnailUrl
    });

    return () => {
      setCurrentMedia(null);
    };
  }, [video, navigate, setCurrentMedia]);

  if (!video) return null;

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto p-4">
        <header className="flex items-center gap-4 mb-6">
          <button 
            onClick={() => navigate(-1)}
            className="p-2 hover:bg-muted rounded-full transition-colors"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-semibold">Lecture</h1>
        </header>

        <div className="space-y-6">
          <div className="aspect-video bg-black rounded-lg overflow-hidden">
            <iframe
              src={getEmbedUrl(video.videoUrl)}
              className="w-full h-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>

          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-semibold">{video.title}</h2>
              <LikeButton contentType="video" contentId={video.id || video.title} />
            </div>
            <p className="text-sm text-muted-foreground">{video.author}</p>
            {video.description && (
              <p className="text-muted-foreground text-sm leading-relaxed">
                {video.description}
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoPlayer;
