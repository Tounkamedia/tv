
import { useState } from 'react';
import { ChevronLeft, Play, Search, ChevronDown } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { getPodcasts } from '../services/googleSheets';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

const PodcastPage = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [displayCount, setDisplayCount] = useState(20);

  const { data: podcasts, isLoading, error } = useQuery({
    queryKey: ['podcasts'],
    queryFn: getPodcasts
  });

  // Tri des podcasts par date (plus récents en haut)
  // En supposant qu'il y a un champ date dans l'objet podcast
  const sortedPodcasts = podcasts?.slice().sort((a, b) => {
    // Si nous n'avons pas d'information de date explicite, nous pouvons utiliser d'autres champs
    // comme une référence pour déterminer la récence, par exemple 'id' ou 'duration'
    
    // Essayons de convertir la durée en minutes si c'est au format "MM:SS"
    const getDurationInMinutes = (duration: string) => {
      const parts = duration.split(':');
      if (parts.length === 2) {
        return parseInt(parts[0]) + parseInt(parts[1]) / 60;
      }
      return 0;
    };
    
    // Comparaison basée sur la durée (plus longue = plus récente)
    // C'est juste un exemple - dans un cas réel, il faudrait une vraie date
    const durationA = getDurationInMinutes(a.duration || '0:00');
    const durationB = getDurationInMinutes(b.duration || '0:00');
    
    return durationB - durationA;
  });

  const filteredPodcasts = sortedPodcasts?.filter(podcast =>
    podcast.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    podcast.author.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const visiblePodcasts = filteredPodcasts?.slice(0, displayCount);
  const hasMorePodcasts = filteredPodcasts && displayCount < filteredPodcasts.length;

  const loadMore = () => {
    setDisplayCount(prev => prev + 30);
  };

  if (isLoading) {
    return <div className="min-h-screen bg-background p-4">Chargement...</div>;
  }

  if (error) {
    return <div className="min-h-screen bg-background p-4">Erreur de chargement des podcasts</div>;
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="max-w-2xl mx-auto p-4">
        <header className="flex items-center gap-4 mb-6">
          <Link to="/" className="text-muted-foreground hover:text-foreground transition-colors">
            <ChevronLeft className="w-6 h-6" />
          </Link>
          <h1 className="text-xl font-semibold">Podcasts</h1>
        </header>

        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
          <Input
            type="text"
            placeholder="Rechercher un podcast..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 animate-fade-in">
          {visiblePodcasts?.map((podcast, index) => (
            <div
              key={index}
              className="space-y-2 cursor-pointer"
              onClick={() => navigate(`/podcasts/${index}`, { state: { podcast } })}
            >
              <div className="aspect-square rounded-2xl overflow-hidden bg-muted">
                <img 
                  src={podcast.cover} 
                  alt={podcast.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="px-1">
                <h3 className="font-medium text-sm line-clamp-2">{podcast.title}</h3>
                <p className="text-xs text-muted-foreground">{podcast.duration}</p>
              </div>
            </div>
          ))}
        </div>

        {hasMorePodcasts && (
          <div className="mt-8 flex justify-center">
            <Button 
              variant="outline" 
              className="gap-2 px-8" 
              onClick={loadMore}
            >
              Voir plus
              <ChevronDown className="w-4 h-4" />
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default PodcastPage;
