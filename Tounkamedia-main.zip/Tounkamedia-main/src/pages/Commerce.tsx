
import { useState, useEffect } from 'react';
import { ChevronLeft, MapPin, Search, SlidersHorizontal } from 'lucide-react';
import { Link } from 'react-router-dom';

const categories = [
  "Tous", "Restaurants", "Supermarchés", "Mode", "Beauté", "Services"
];

const places = [
  {
    id: 1,
    name: "Restaurant Le Délice",
    category: "Restaurants",
    address: "123 Rue du Commerce",
    distance: "0.3",
    rating: 4.5,
    image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800&auto=format&fit=crop&q=60"
  },
  {
    id: 2,
    name: "Supermarché Express",
    category: "Supermarchés",
    address: "45 Avenue Centrale",
    distance: "0.7",
    rating: 4.2,
    image: "https://images.unsplash.com/photo-1534723452862-4c874018d66d?w=800&auto=format&fit=crop&q=60"
  },
  {
    id: 3,
    name: "Fashion Store",
    category: "Mode",
    address: "89 Boulevard Shopping",
    distance: "1.2",
    rating: 4.0,
    image: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=800&auto=format&fit=crop&q=60"
  }
];

const CommercePage = () => {
  const [selectedCategory, setSelectedCategory] = useState("Tous");
  const [maxDistance, setMaxDistance] = useState(5);
  const [searchQuery, setSearchQuery] = useState("");
  const [userLocation, setUserLocation] = useState<GeolocationPosition | null>(null);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => setUserLocation(position),
        (error) => console.log("Erreur de géolocalisation:", error)
      );
    }
  }, []);

  const filteredPlaces = places.filter((place) => {
    const matchesCategory = selectedCategory === "Tous" || place.category === selectedCategory;
    const matchesDistance = Number(place.distance) <= maxDistance;
    const matchesSearch = place.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         place.address.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesDistance && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="max-w-2xl mx-auto p-4">
        <header className="flex items-center gap-4 mb-6">
          <Link to="/" className="text-muted-foreground hover:text-foreground transition-colors">
            <ChevronLeft className="w-6 h-6" />
          </Link>
          <h1 className="text-xl font-semibold">Commerce</h1>
        </header>

        <div className="space-y-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <input
              type="text"
              placeholder="Rechercher un commerce..."
              className="w-full pl-10 pr-4 py-2 rounded-lg border focus:outline-none focus:ring-2 focus:ring-primary"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <div className="flex items-center gap-2 overflow-x-auto pb-2">
            {categories.map((category) => (
              <button
                key={category}
                className={`px-4 py-2 rounded-full whitespace-nowrap ${
                  selectedCategory === category
                    ? 'bg-primary text-white'
                    : 'bg-muted hover:bg-muted/80'
                }`}
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-4">
            <SlidersHorizontal className="w-5 h-5 text-muted-foreground" />
            <input
              type="range"
              min="1"
              max="10"
              value={maxDistance}
              onChange={(e) => setMaxDistance(Number(e.target.value))}
              className="flex-1"
            />
            <span className="text-sm text-muted-foreground">{maxDistance} km</span>
          </div>

          <div className="grid gap-4 animate-fade-in">
            {filteredPlaces.map((place) => (
              <div
                key={place.id}
                className="flex gap-4 bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="w-24 h-24 bg-muted rounded-md overflow-hidden flex-shrink-0">
                  <img 
                    src={place.image} 
                    alt={place.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1">
                  <h3 className="font-medium">{place.name}</h3>
                  <p className="text-sm text-muted-foreground">{place.category}</p>
                  <div className="flex items-center gap-1 mt-2 text-sm text-muted-foreground">
                    <MapPin className="w-4 h-4" />
                    <span>{place.address}</span>
                  </div>
                  <div className="flex items-center gap-2 mt-2">
                    <span className="text-sm text-primary">{place.distance} km</span>
                    <span className="text-sm">⭐ {place.rating}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CommercePage;
