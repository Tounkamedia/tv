import { Video, Headphones, Radio, Tv, ShoppingBag } from 'lucide-react';
import { motion } from 'framer-motion';
import { AdCarousel } from '../components/AdCarousel';
import { AppIcon } from '../components/AppIcon';
import { NavBar } from '../components/NavBar';
import { useNavigate } from 'react-router-dom';
import { useTheme } from '../providers/ThemeProvider';
import { Helmet } from 'react-helmet';
const apps = [{
  icon: Video,
  label: "Vidéos",
  color: "#F97316",
  route: "/videos"
}, {
  icon: Headphones,
  label: "Podcasts",
  color: "#9b87f5",
  route: "/podcasts",
  showBadge: true
}, {
  icon: Radio,
  label: "Radio",
  color: "#FEC6A1",
  route: "/radio",
  showBadge: true
}, {
  icon: Tv,
  label: "Direct",
  color: "#0EA5E9",
  route: "/direct",
  isLive: true
}, {
  icon: ShoppingBag,
  label: "Shopping",
  color: "#D946EF",
  route: "/shopping"
}];
const container = {
  hidden: {
    opacity: 0
  },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};
const item = {
  hidden: {
    y: 20,
    opacity: 0
  },
  show: {
    y: 0,
    opacity: 1
  }
};
const Index = () => {
  const navigate = useNavigate();
  const {
    theme
  } = useTheme();
  return <div className="min-h-screen pb-20 relative">
      <Helmet>
        <title>Tounka TV - Streaming Africain | Vidéos, Podcasts, Radio, TV en Direct</title>
        <meta name="description" content="Tounka TV est votre destination africaine de référence pour des vidéos, podcasts, radios, chaînes TV en direct et shopping africain. Découvrez notre contenu authentique qui célèbre l'identité et la culture africaine." />
        <meta name="keywords" content="streaming africain, vidéos africaines, podcasts africains, radio africaine, TV en direct, culture africaine" />
        <meta property="og:title" content="Tounka TV - Plateforme de Streaming Africain" />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://tounka.tv" />
        <meta property="og:image" content="https://image.noelshack.com/fichiers/2025/09/1/1740420059-tounka-media-logo.png" />
        <meta property="og:description" content="Explorez des vidéos, podcasts, radios et TV en direct qui célèbrent la culture africaine. Tounka TV: bien plus qu'une plateforme, un mouvement pour la renaissance africaine." />
        <link rel="canonical" href="https://tounka.tv" />
      </Helmet>
      {/* Arrière-plan avec un subtil dégradé */}
      <div className="absolute inset-0 z-0 bg-gradient-to-br from-background to-background/80" style={{
      backgroundImage: theme === 'dark' ? 'radial-gradient(circle at top right, rgba(79, 70, 229, 0.05) 0%, transparent 50%)' : 'radial-gradient(circle at top right, rgba(249, 115, 22, 0.05) 0%, transparent 50%)'
    }} />
      
      <motion.div className="max-w-lg mx-auto px-4 relative z-10" initial={{
      opacity: 0
    }} animate={{
      opacity: 1
    }} transition={{
      duration: 0.5
    }}>
        <div className="flex items-center justify-between mt-6 mb-6">
          
        </div>

        <motion.div initial={{
        y: 20,
        opacity: 0
      }} animate={{
        y: 0,
        opacity: 1
      }} transition={{
        duration: 0.3,
        delay: 0.1
      }}>
          <AdCarousel />
        </motion.div>
        
        <motion.div variants={container} initial="hidden" animate="show" className="app-grid mt-8">
          {apps.map(app => <motion.div key={app.label} variants={item} whileHover={{
          scale: 1.05
        }} whileTap={{
          scale: 0.95
        }}>
              <AppIcon icon={app.icon} label={app.label} color={app.color} onClick={() => navigate(app.route)} showBadge={app.showBadge} isLive={app.isLive} />
            </motion.div>)}
        </motion.div>
      </motion.div>
      <NavBar />
    </div>;
};
export default Index;