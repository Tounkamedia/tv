
import { useState } from 'react';
import { ChevronLeft, ExternalLink, Search, ChevronDown } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { getProducts } from '../services/googleSheets';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

const Shopping = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedProduct, setSelectedProduct] = useState<any | null>(null);
  const [displayCount, setDisplayCount] = useState(20);

  const { data: products, isLoading, error } = useQuery({
    queryKey: ['products'],
    queryFn: getProducts
  });

  // Ici, nous supposons qu'un produit plus récemment ajouté possède un ID plus élevé
  // ou une autre propriété qui pourrait indiquer sa récence
  const sortedProducts = products?.slice().sort((a, b) => {
    // Exemple: on utilise l'ordre inverse du tableau pour simuler un tri par date
    // Dans un cas réel, il faudrait utiliser un vrai champ de date
    return -1; // Pour maintenir l'ordre original qui est supposé être par date
  });

  const filteredProducts = sortedProducts?.filter(
    product => product.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
               product.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const visibleProducts = filteredProducts?.slice(0, displayCount);
  const hasMoreProducts = filteredProducts && displayCount < filteredProducts.length;

  const loadMore = () => {
    setDisplayCount(prev => prev + 30);
  };

  if (isLoading) {
    return <div className="min-h-screen bg-background p-4">Chargement...</div>;
  }

  if (error) {
    return <div className="min-h-screen bg-background p-4">Erreur de chargement des produits</div>;
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="max-w-2xl mx-auto p-4">
        <header className="flex items-center gap-4 mb-6">
          <button 
            onClick={() => navigate(-1)}
            className="p-2 hover:bg-muted rounded-full transition-colors"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-semibold">Shopping</h1>
        </header>

        {selectedProduct ? (
          <div className="space-y-6 animate-fade-in">
            <div className="aspect-[3/4] bg-white rounded-xl overflow-hidden">
              <img 
                src={selectedProduct.image} 
                alt={selectedProduct.title}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="space-y-4">
              <div>
                <h2 className="text-xl font-medium dark:text-white">{selectedProduct.title}</h2>
                <p className="text-2xl font-bold text-primary mt-2">{selectedProduct.price} €</p>
                <p className="text-sm text-muted-foreground">Vendu par {selectedProduct.merchant}</p>
              </div>
              <div className="bg-[#1a1a1a] p-4 rounded-lg">
                <p className="text-white leading-relaxed">
                  {selectedProduct.description}
                </p>
              </div>
              <div className="flex gap-4">
                <a
                  href={selectedProduct.buyUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 flex items-center justify-center gap-2 bg-primary text-white px-6 py-3 rounded-lg hover:bg-primary/90 transition-colors"
                >
                  <span>Acheter maintenant</span>
                  <ExternalLink className="w-4 h-4" />
                </a>
                <button
                  onClick={() => setSelectedProduct(null)}
                  className="px-6 py-3 border rounded-lg hover:bg-muted/50 transition-colors"
                >
                  Retour
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
              <Input
                type="text"
                placeholder="Rechercher un produit..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 animate-fade-in">
              {visibleProducts?.map((product, index) => (
                <button
                  key={index}
                  className="text-left space-y-2 flex flex-col h-full"
                  onClick={() => setSelectedProduct(product)}
                >
                  <div className="aspect-[3/4] w-full bg-white rounded-xl overflow-hidden">
                    <img 
                      src={product.image} 
                      alt={product.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="px-1 flex-1 flex flex-col">
                    <h3 className="font-medium line-clamp-2 min-h-[2.5rem] text-sm">{product.title}</h3>
                    <p className="text-primary font-medium mt-auto">{product.price} €</p>
                    <p className="text-xs text-muted-foreground">{product.merchant}</p>
                  </div>
                </button>
              ))}
            </div>

            {hasMoreProducts && (
              <div className="mt-8 flex justify-center">
                <Button 
                  variant="outline" 
                  className="gap-2 px-8" 
                  onClick={loadMore}
                >
                  Voir plus
                  <ChevronDown className="w-4 h-4" />
                </Button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Shopping;
