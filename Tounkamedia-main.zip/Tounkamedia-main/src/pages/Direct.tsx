
import { useState } from 'react';
import { ChevronLeft, Play, Search, ChevronDown } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { getDirectChannels } from '../services/googleSheets';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

const DirectPage = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [displayCount, setDisplayCount] = useState(20);

  const { data: channels, isLoading, error } = useQuery({
    queryKey: ['direct'],
    queryFn: getDirectChannels
  });

  // Tri des chaînes par ordre alphabétique
  const sortedChannels = channels?.slice().sort((a, b) => 
    a.title.localeCompare(b.title)
  );

  const filteredChannels = sortedChannels?.filter(channel =>
    channel.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    channel.genre?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const visibleChannels = filteredChannels?.slice(0, displayCount);
  const hasMoreChannels = filteredChannels && displayCount < filteredChannels.length;

  const loadMore = () => {
    setDisplayCount(prev => prev + 30);
  };

  if (isLoading) {
    return <div className="min-h-screen bg-background p-4">Chargement...</div>;
  }

  if (error) {
    return <div className="min-h-screen bg-background p-4">Erreur de chargement des chaînes</div>;
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="max-w-2xl mx-auto p-4">
        <header className="flex items-center gap-4 mb-6">
          <Link to="/" className="text-muted-foreground hover:text-foreground transition-colors">
            <ChevronLeft className="w-6 h-6" />
          </Link>
          <h1 className="text-xl font-semibold">Direct TV</h1>
        </header>

        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
          <Input
            type="text"
            placeholder="Rechercher une chaîne..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 animate-fade-in">
          {visibleChannels?.map((channel, index) => (
            <button
              key={index}
              className="group p-4 bg-[#1a1a1a] rounded-lg shadow-sm hover:shadow-md transition-all"
              onClick={() => navigate(`/direct/player`, { state: { channel } })}
            >
              <div className="relative aspect-square rounded-lg overflow-hidden mb-2">
                <img 
                  src={channel.logo} 
                  alt={channel.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <Play className="w-12 h-12 text-white" />
                </div>
              </div>
              <h3 className="font-medium text-sm text-left text-white">{channel.title}</h3>
              <p className="text-xs text-white/70 text-left">{channel.genre}</p>
            </button>
          ))}
        </div>

        {hasMoreChannels && (
          <div className="mt-8 flex justify-center">
            <Button 
              variant="outline" 
              className="gap-2 px-8" 
              onClick={loadMore}
            >
              Voir plus
              <ChevronDown className="w-4 h-4" />
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default DirectPage;
