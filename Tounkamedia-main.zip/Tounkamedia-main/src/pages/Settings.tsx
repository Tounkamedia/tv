
import { Youtube, Mail, X } from 'lucide-react';
import { NavBar } from '../components/NavBar';
import { useTheme } from '../providers/ThemeProvider';

const Settings = () => {
  const { theme, toggleTheme } = useTheme();
  const isDark = theme === 'dark';

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="max-w-lg mx-auto p-6">
        <h1 className="text-2xl font-bold mb-8 text-center">Paramètres</h1>

        <div className="space-y-8">
          <div className={`p-6 rounded-xl ${isDark ? 'glass-effect glass-effect-dark' : 'glass-effect glass-effect-light'}`}>
            <h2 className="text-xl font-medium mb-5">Préférences</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-lg">Mode sombre</span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    className="sr-only peer" 
                    checked={isDark}
                    onChange={toggleTheme}
                  />
                  <div className="w-14 h-7 bg-gray-300 rounded-full peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary/25 dark:peer-focus:ring-primary/25 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all dark:border-gray-600 peer-checked:bg-primary"></div>
                </label>
              </div>
            </div>
          </div>

          <div className={`p-6 rounded-xl ${isDark ? 'glass-effect glass-effect-dark' : 'glass-effect glass-effect-light'}`}>
            <h2 className="text-xl font-medium mb-5">Réseaux sociaux</h2>
            <div className="grid grid-cols-5 gap-6">
              <a href="https://x.com/tounka_tv" target="_blank" rel="noopener noreferrer" className="flex flex-col items-center">
                <div className="w-14 h-14 rounded-full bg-black flex items-center justify-center hover:opacity-90 transition-colors">
                  <X className="w-7 h-7 text-white fill-current" />
                </div>
                <span className="text-sm mt-2">Twitter</span>
              </a>
              <a href="https://www.youtube.com/@TOUNKATV" target="_blank" rel="noopener noreferrer" className="flex flex-col items-center">
                <div className="w-14 h-14 rounded-full bg-red-600 flex items-center justify-center hover:opacity-90 transition-colors">
                  <Youtube className="w-7 h-7 text-white fill-current" />
                </div>
                <span className="text-sm mt-2">YouTube</span>
              </a>
              <a href="https://facebook.com/tounkatv" target="_blank" rel="noopener noreferrer" className="flex flex-col items-center">
                <div className="w-14 h-14 rounded-full bg-blue-600 flex items-center justify-center hover:opacity-90 transition-colors">
                  <svg className="w-7 h-7 text-white" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                  </svg>
                </div>
                <span className="text-sm mt-2">Facebook</span>
              </a>
              <a href="https://instagram.com/tounkatv" target="_blank" rel="noopener noreferrer" className="flex flex-col items-center">
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-purple-600 via-pink-500 to-orange-400 flex items-center justify-center hover:opacity-90 transition-colors">
                  <svg className="w-7 h-7 text-white" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M12 2c2.717 0 3.056.01 4.122.06 1.065.05 1.79.217 2.428.465.66.254 1.216.598 1.772 1.153.509.5.902 1.105 1.153 1.772.247.637.415 1.363.465 2.428.047 1.066.06 1.405.06 4.122 0 2.717-.01 3.056-.06 4.122-.05 1.065-.218 1.79-.465 2.428a4.883 4.883 0 01-1.153 1.772c-.5.508-1.105.902-1.772 1.153-.637.247-1.363.415-2.428.465-1.066.047-1.405.06-4.122.06-2.717 0-3.056-.01-4.122-.06-1.065-.05-1.79-.218-2.428-.465a4.89 4.89 0 01-1.772-1.153 4.904 4.904 0 01-1.153-1.772c-.247-.637-.415-1.363-.465-2.428C2.013 15.056 2 14.717 2 12c0-2.717.01-3.056.06-4.122.05-1.066.217-1.79.465-2.428a4.88 4.88 0 011.153-1.772A4.897 4.897 0 015.45 2.525c.638-.247 1.362-.415 2.428-.465C8.944 2.013 9.283 2 12 2zm0 1.802c-2.67 0-2.986.01-4.04.059-.976.045-1.505.207-1.858.344-.466.181-.8.398-1.15.748-.35.35-.566.683-.748 1.15-.137.353-.3.882-.344 1.857-.047 1.055-.059 1.37-.059 4.04 0 2.669.01 2.986.059 4.04.045.975.207 1.504.344 1.857.181.466.399.8.748 1.15.35.35.683.566 1.15.747.353.137.882.3 1.857.345 1.054.046 1.37.058 4.04.058 2.67 0 2.986-.01 4.04-.058.975-.046 1.504-.208 1.857-.345.466-.181.8-.398 1.15-.748.35-.35.566-.683.747-1.15.137-.352.3-.882.345-1.857.047-1.054.058-1.37.058-4.04 0-2.67-.01-2.986-.058-4.04-.045-.975-.208-1.504-.345-1.857a3.097 3.097 0 00-.747-1.15 3.098 3.098 0 00-1.15-.747c-.353-.137-.882-.3-1.857-.345-1.054-.047-1.37-.059-4.04-.059zm0 3.063a5.135 5.135 0 110 10.27 5.135 5.135 0 010-10.27zm0 8.468a3.333 3.333 0 100-6.666 3.333 3.333 0 000 6.666zm6.538-8.671a1.2 1.2 0 11-2.4 0 1.2 1.2 0 012.4 0z" />
                  </svg>
                </div>
                <span className="text-sm mt-2">Instagram</span>
              </a>
              <a href="https://tiktok.com/@tounka.tv" target="_blank" rel="noopener noreferrer" className="flex flex-col items-center">
                <div className="w-14 h-14 rounded-full bg-black flex items-center justify-center hover:opacity-90 transition-colors">
                  <svg className="w-7 h-7 text-white" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z" />
                  </svg>
                </div>
                <span className="text-sm mt-2">TikTok</span>
              </a>
            </div>
          </div>

          <div className={`p-6 rounded-xl ${isDark ? 'glass-effect glass-effect-dark' : 'glass-effect glass-effect-light'}`}>
            <h2 className="text-xl font-medium mb-5">À propos</h2>
            <div className="space-y-5">
              <div className="text-sm space-y-4 text-foreground">
                <p>Bienvenue sur Tounka, l'espace où l'histoire, la culture et l'identité africaine sont mises en lumière comme jamais auparavant. Ici, nous ne nous contentons pas de divertir : nous éveillons les consciences, nous inspirons et nous célébrons nos traditions avec fierté.</p>
                
                <p className="font-medium text-base">📡 Ce que tu trouveras sur Tounka :</p>
                <ul className="list-none space-y-2 pl-4">
                  <li>✅ Chaînes TV en direct – Suis l'actualité et les événements en temps réel.</li>
                  <li>🎧 Radios & Podcasts – Écoute des voix engagées et des récits inspirants.</li>
                  <li>🎥 Vidéos & Documentaires – Découvre des contenus qui valorisent notre histoire et nos luttes.</li>
                  <li>🛍️ Shopping Africain – Soutiens les créateurs et commerçants du continent.</li>
                </ul>

                <p className="font-medium text-base">⚡ Notre mission ?</p>
                <ul className="list-none space-y-2 pl-4">
                  <li>🔗 Éveiller les consciences – En partageant une information authentique et libératrice.</li>
                  <li>🌍 Réaffirmer notre identité – En mettant en avant les cultures et traditions africaines.</li>
                  <li>💡 Créer un espace d'échange – Où chaque voix de la diaspora et du continent compte.</li>
                </ul>

                <div className="mt-5 flex items-center gap-3 pt-3 border-t">
                  <Mail className="w-5 h-5 text-primary" />
                  <a href="mailto:tounka.media@gmail.com" className="text-primary hover:underline text-base">
                    tounka.media@gmail.com
                  </a>
                </div>

                <p className="pt-4 text-sm text-center">🚀 Tounka, bien plus qu'une plateforme : un mouvement pour la renaissance africaine. 👑</p>
              </div>
              <p className="text-sm text-foreground pt-2">Version 1.0.0</p>
              <p className="text-sm text-foreground">© 2023 Tounka Média</p>
            </div>
          </div>
        </div>
      </div>
      <NavBar />
    </div>
  );
};

export default Settings;
