
import { useState, useRef, useEffect } from 'react';
import { ChevronLeft, Play, Pause, SkipBack, SkipForward } from 'lucide-react';
import { useLocation, useNavigate } from 'react-router-dom';
import { usePlayerStore } from '../store/playerStore';
import PersistentPlayer from '../components/PersistentPlayer';
import { LikeButton } from '../components/LikeButton';

const PodcastPlayer = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const podcast = location.state?.podcast;
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const { setCurrentMedia, currentMedia, isPlaying, setIsPlaying, stopAllMedia } = usePlayerStore();
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (!podcast) {
      navigate('/podcasts');
      return;
    }

    // Arrêter tous les autres médias avant de jouer le podcast
    stopAllMedia();

    setCurrentMedia({
      title: podcast.title,
      type: 'podcast',
      url: podcast.audioUrl,
      coverImage: podcast.cover
    });

    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, [podcast, navigate, setCurrentMedia, stopAllMedia]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setProgress(audioRef.current.currentTime);
      setDuration(audioRef.current.duration);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value);
    if (audioRef.current) {
      audioRef.current.currentTime = value;
      setProgress(value);
    }
  };

  useEffect(() => {
    if (!audioRef.current && podcast) {
      audioRef.current = new Audio(podcast.audioUrl);
      audioRef.current.addEventListener('timeupdate', handleTimeUpdate);
    }

    return () => {
      if (audioRef.current) {
        audioRef.current.removeEventListener('timeupdate', handleTimeUpdate);
      }
    };
  }, [podcast]);

  useEffect(() => {
    if (!isPlaying && audioRef.current) {
      audioRef.current.pause();
    } else if (isPlaying && audioRef.current) {
      audioRef.current.play().catch(console.error);
    }
  }, [isPlaying]);

  const handleClose = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    setIsPlaying(false);
    setCurrentMedia(null);
  };

  if (!podcast) {
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-2xl mx-auto p-4">
        <header className="flex items-center gap-4 mb-6">
          <button 
            onClick={() => navigate(-1)}
            className="p-2 hover:bg-muted rounded-full transition-colors"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-semibold">Lecture</h1>
        </header>

        <div className="space-y-8 pb-20">
          <div className="aspect-square max-w-md mx-auto rounded-3xl overflow-hidden shadow-xl">
            <img 
              src={podcast.cover} 
              alt={podcast.title}
              className="w-full h-full object-cover"
            />
          </div>

          <div className="space-y-2 text-center">
            <div className="flex justify-center items-center gap-4">
              <h2 className="text-2xl font-semibold">{podcast.title}</h2>
              <LikeButton contentType="podcast" contentId={podcast.id || podcast.title} />
            </div>
            <p className="text-muted-foreground">{podcast.author}</p>
          </div>

          {podcast.description && (
            <p className="text-muted-foreground text-sm leading-relaxed">
              {podcast.description}
            </p>
          )}

          <div className="space-y-4">
            <div className="flex items-center gap-3 text-sm">
              <span className="text-muted-foreground">{formatTime(progress)}</span>
              <input
                type="range"
                min="0"
                max={duration || 100}
                value={progress}
                onChange={handleSeek}
                className="flex-1 h-1 bg-muted rounded-full appearance-none [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-primary"
              />
              <span className="text-muted-foreground">{formatTime(duration)}</span>
            </div>

            <div className="flex items-center justify-center gap-4">
              <button
                className="p-2 text-muted-foreground hover:text-foreground transition-colors"
                onClick={() => {
                  if (audioRef.current) {
                    audioRef.current.currentTime = Math.max(0, audioRef.current.currentTime - 10);
                  }
                }}
              >
                <SkipBack className="w-8 h-8" />
              </button>

              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="w-16 h-16 rounded-full bg-primary text-white flex items-center justify-center hover:bg-primary/90 transition-colors"
              >
                {isPlaying ? (
                  <Pause className="w-8 h-8" />
                ) : (
                  <Play className="w-8 h-8" />
                )}
              </button>

              <button
                className="p-2 text-muted-foreground hover:text-foreground transition-colors"
                onClick={() => {
                  if (audioRef.current) {
                    audioRef.current.currentTime = Math.min(
                      audioRef.current.duration,
                      audioRef.current.currentTime + 10
                    );
                  }
                }}
              >
                <SkipForward className="w-8 h-8" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {currentMedia?.type === 'podcast' && (
        <PersistentPlayer
          title={currentMedia.title}
          type="podcast"
          isPlaying={isPlaying}
          coverImage={currentMedia.coverImage}
          onTogglePlay={() => setIsPlaying(!isPlaying)}
          onClose={handleClose}
        />
      )}
    </div>
  );
};

export default PodcastPlayer;
