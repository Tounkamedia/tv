
import { useState } from 'react';
import { ChevronLeft, Play } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { getMovies } from '../services/googleSheets';
import { usePlayerStore } from '../store/playerStore';
import { getEmbedUrl } from '../utils/videoUtils';
import { NavBar } from '../components/NavBar';

const MoviesPage = () => {
  const navigate = useNavigate();
  const [selectedMovie, setSelectedMovie] = useState<any | null>(null);
  const { setCurrentMedia, isMinimized, setIsMinimized } = usePlayerStore();

  const { data: movies, isLoading, error } = useQuery({
    queryKey: ['movies'],
    queryFn: getMovies
  });

  const handleMovieSelect = (movie: any) => {
    navigate('/movies/player', { state: { movie } });
  };

  const formatDate = (dateString: string) => {
    try {
      return new Date(dateString).toLocaleDateString('fr-FR', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
      });
    } catch (e) {
      return dateString;
    }
  };

  if (isLoading) {
    return <div className="min-h-screen bg-background p-4">Chargement...</div>;
  }

  if (error) {
    return <div className="min-h-screen bg-background p-4">Erreur de chargement</div>;
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="max-w-2xl mx-auto p-4">
        <header className="flex items-center gap-4 mb-6">
          <button 
            onClick={() => navigate(-1)}
            className="p-2 hover:bg-muted rounded-full transition-colors"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-semibold">Films & Séries</h1>
        </header>

        <div className="grid gap-6 animate-fade-in">
          {movies?.map((movie, index) => (
            <div
              key={index}
              className="space-y-3 cursor-pointer"
              onClick={() => handleMovieSelect(movie)}
            >
              <div className="relative aspect-[2/3] bg-muted rounded-lg overflow-hidden">
                <img 
                  src={movie.coverImage}
                  alt={movie.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 flex items-center justify-center bg-black/20 hover:bg-black/40 transition-opacity">
                  <Play className="w-12 h-12 text-white" />
                </div>
              </div>
              <div className="px-1 space-y-1">
                <h3 className="font-medium line-clamp-2">{movie.title}</h3>
                <p className="text-sm text-muted-foreground">
                  {movie.genre} • {movie.duration}
                </p>
                <p className="text-sm text-muted-foreground">
                  {formatDate(movie.releaseDate)}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
      <NavBar />
    </div>
  );
};

export default MoviesPage;
