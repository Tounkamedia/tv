
import { useState } from 'react';
import { ChevronLeft, Play, Search, ChevronDown } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { getVideos } from '../services/googleSheets';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

const VideoPage = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [displayCount, setDisplayCount] = useState(20);

  const { data: videos, isLoading, error } = useQuery({
    queryKey: ['videos'],
    queryFn: getVideos
  });

  // Tri des vidéos par date (plus récentes en haut)
  const sortedVideos = videos?.slice().sort((a, b) => {
    // Convertir les dates en format standard si possible
    const dateA = new Date(a.date);
    const dateB = new Date(b.date);
    
    // Vérifier si les dates sont valides, sinon comparer les chaînes
    if (!isNaN(dateA.getTime()) && !isNaN(dateB.getTime())) {
      return dateB.getTime() - dateA.getTime(); // Plus récent en premier
    }
    
    // Fallback sur la comparaison de chaînes si les dates ne sont pas valides
    return b.date?.localeCompare(a.date || '') || 0;
  });

  const filteredVideos = sortedVideos?.filter(video =>
    video.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    video.genre?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const visibleVideos = filteredVideos?.slice(0, displayCount);
  const hasMoreVideos = filteredVideos && displayCount < filteredVideos.length;

  const loadMore = () => {
    setDisplayCount(prev => prev + 30);
  };

  if (isLoading) {
    return <div className="min-h-screen bg-background p-4">Chargement...</div>;
  }

  if (error) {
    return <div className="min-h-screen bg-background p-4">Erreur de chargement des vidéos</div>;
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <div className="max-w-2xl mx-auto p-4">
        <header className="flex items-center gap-4 mb-6">
          <button 
            onClick={() => navigate(-1)}
            className="p-2 hover:bg-muted rounded-full transition-colors"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-semibold">Vidéos</h1>
        </header>

        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
          <Input
            type="text"
            placeholder="Rechercher une vidéo..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        <div className="grid gap-6 animate-fade-in">
          {visibleVideos?.map((video, index) => (
            <div
              key={index}
              className="space-y-3 cursor-pointer"
              onClick={() => navigate(`/videos/${index}`, { state: { video } })}
            >
              <div className="relative aspect-video bg-muted rounded-lg overflow-hidden">
                <img 
                  src={video.thumbnailUrl || video.videoUrl}
                  alt={video.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 flex items-center justify-center bg-black/20 hover:bg-black/40 transition-opacity">
                  <Play className="w-12 h-12 text-white" />
                </div>
              </div>
              <div className="px-1 space-y-1">
                <h3 className="font-medium line-clamp-2">{video.title}</h3>
                <p className="text-sm text-muted-foreground">
                  {video.author}
                </p>
                <p className="text-sm text-muted-foreground">
                  {video.date}
                </p>
              </div>
            </div>
          ))}
        </div>

        {hasMoreVideos && (
          <div className="mt-8 flex justify-center">
            <Button 
              variant="outline" 
              className="gap-2 px-8" 
              onClick={loadMore}
            >
              Voir plus
              <ChevronDown className="w-4 h-4" />
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default VideoPage;
