
import React, { useEffect } from 'react';
import { ChevronLeft } from 'lucide-react';
import { useLocation, useNavigate } from 'react-router-dom';
import { usePlayerStore } from '../store/playerStore';
import { getEmbedUrl } from '../utils/videoUtils';
import { LikeButton } from '../components/LikeButton';

const DirectPlayer = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { channel } = location.state || {};
  const { setCurrentMedia } = usePlayerStore();

  useEffect(() => {
    if (!channel) {
      navigate('/direct');
      return;
    }

    const embedUrl = getEmbedUrl(channel.streamUrl);
    setCurrentMedia({
      title: channel.title,
      type: 'video',
      url: embedUrl,
      coverImage: channel.logo
    });

    return () => {
      setCurrentMedia(null);
    };
  }, [channel, navigate, setCurrentMedia]);

  if (!channel) return null;

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto p-4">
        <header className="flex items-center gap-4 mb-6">
          <button 
            onClick={() => navigate('/direct')}
            className="p-2 hover:bg-muted rounded-full transition-colors"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <h1 className="text-xl font-semibold">Direct TV</h1>
        </header>

        <div className="space-y-6">
          <div className="aspect-video bg-black rounded-lg overflow-hidden">
            <iframe
              src={getEmbedUrl(channel.streamUrl)}
              className="w-full h-full"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>

          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-semibold">{channel.title}</h2>
              <LikeButton contentType="direct" contentId={channel.id || channel.title} />
            </div>
            <p className="text-sm text-muted-foreground">{channel.genre}</p>
            {channel.description && (
              <p className="text-muted-foreground text-sm leading-relaxed">
                {channel.description}
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DirectPlayer;
