
import { useState, useEffect } from 'react';

type ContentType = 'video' | 'podcast' | 'direct';

export function useLikes() {
  const [likedContent, setLikedContent] = useState<Record<string, boolean>>({});

  // Charger les likes du localStorage au démarrage
  useEffect(() => {
    const storedLikes = localStorage.getItem('tounka_likes');
    if (storedLikes) {
      try {
        const parsedLikes = JSON.parse(storedLikes);
        setLikedContent(parsedLikes);
      } catch (e) {
        console.error('Erreur lors du chargement des likes:', e);
      }
    }
  }, []);

  // Sauvegarder les likes avec une date d'expiration d'un an
  const saveLikes = (likes: Record<string, boolean>) => {
    try {
      localStorage.setItem('tounka_likes', JSON.stringify(likes));
      
      // Définir une date d'expiration d'un an
      const expiryDate = new Date();
      expiryDate.setFullYear(expiryDate.getFullYear() + 1);
      localStorage.setItem('tounka_likes_expiry', expiryDate.toISOString());
    } catch (e) {
      console.error('Erreur lors de la sauvegarde des likes:', e);
    }
  };

  // Vérifier si un contenu est liké
  const isLiked = (contentType: ContentType, contentId: string) => {
    const key = `${contentType}_${contentId}`;
    return !!likedContent[key];
  };

  // Basculer l'état "like" d'un contenu
  const toggleLike = (contentType: ContentType, contentId: string) => {
    const key = `${contentType}_${contentId}`;
    const newLikedContent = {
      ...likedContent,
      [key]: !likedContent[key]
    };
    
    setLikedContent(newLikedContent);
    saveLikes(newLikedContent);
    
    return !likedContent[key]; // Retourne le nouvel état
  };

  // Vérifier et nettoyer les likes expirés
  useEffect(() => {
    const checkExpiry = () => {
      const expiryDateStr = localStorage.getItem('tounka_likes_expiry');
      if (expiryDateStr) {
        const expiryDate = new Date(expiryDateStr);
        const now = new Date();
        
        if (now > expiryDate) {
          // Les likes ont expiré, on les supprime
          localStorage.removeItem('tounka_likes');
          localStorage.removeItem('tounka_likes_expiry');
          setLikedContent({});
        }
      }
    };
    
    checkExpiry();
  }, []);

  return { isLiked, toggleLike };
}
