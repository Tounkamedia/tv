const SHEETS_API_KEY = 'AIzaSyAdj2a4uFpwWZ21bK9F30Ew_W2Z_Oftrv8';

interface SheetConfig {
  spreadsheetId: string;
  range: string;
}

interface Movie {
  title: string;
  coverImage: string;
  releaseDate: string;
  duration: string;
  description: string;
  genre: string;
  episodeUrl?: string;
  videoUrl: string;
}

const SHEETS_CONFIG = {
  videos: {
    spreadsheetId: '1CPGkMDZyWCTjEAzWWPOBONJ0AsgzqojhUnxAk3f8ns4',
    range: 'videos_tounka!A2:G'
  },
  podcasts: {
    spreadsheetId: '1-fARRUQR2eVahd77Ljt_q8TQreZM3fTdAiFxT05B2sU',
    range: 'podcasts_tounka!A2:F'
  },
  radios: {
    spreadsheetId: '1oynaqMSA1821ALWvyUE31LBM7gzP0lyKh_-iuiOgD_k',
    range: 'radios_tounka!A2:D'
  },
  direct: {
    spreadsheetId: '1gEiuhZKCU6xYd5HQIr059fVKFi3xiWzfa-FAm1wZ_fM',
    range: 'direct_tounka!A2:D'
  },
  shopping: {
    spreadsheetId: '15F5rZE9GPIPeYJq4U03x0kjPrc2gNHMSb1lrujErUQM',
    range: 'shopping_tounka!A2:F'
  },
  movies: {
    spreadsheetId: '1xkd0EeZieoVautiYl3BI7OB7sG4orjYD_2czPSZLQ2M',
    range: 'films_series_tounka!A2:H'
  }
};

async function fetchSheetData(config: SheetConfig) {
  try {
    const url = `https://sheets.googleapis.com/v4/spreadsheets/${config.spreadsheetId}/values/${config.range}?key=${SHEETS_API_KEY}`;
    console.log('Fetching data from:', url);
    
    const response = await fetch(url);
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const data = await response.json();
    if (!data || !data.values) {
      console.warn('No data found in sheet');
      return [];
    }
    
    console.log('Data fetched successfully:', data.values);
    return data.values;
  } catch (error) {
    console.error('Error fetching sheet data:', error);
    throw error;
  }
}

// Interface pour les vidéos
interface Video {
  title: string;
  videoUrl: string;
  author: string;
  date: string;
  description: string;
  genre: string;
  thumbnailUrl: string;
}

export const getVideos = async (): Promise<Video[]> => {
  const data = await fetchSheetData(SHEETS_CONFIG.videos);
  return data.map(row => ({
    title: row[0] || '',
    videoUrl: row[1] || '',
    author: row[2] || '',
    date: row[3] || '',
    description: row[4] || '',
    genre: row[5] || '',
    thumbnailUrl: row[6] || ''
  }));
};

// Interface pour les podcasts
interface Podcast {
  title: string;
  author: string;
  duration: string;
  genre: string;
  audioUrl: string;
  cover: string;
}

export const getPodcasts = async (): Promise<Podcast[]> => {
  const data = await fetchSheetData(SHEETS_CONFIG.podcasts);
  return data.map(row => ({
    title: row[0] || '',
    author: row[1] || '',
    duration: row[2] || '',
    genre: row[3] || '',
    audioUrl: row[4] || '',
    cover: row[5] || ''
  }));
};

// Interface pour les radios
interface Radio {
  name: string;
  logo: string;
  genre: string;
  streamUrl: string;
}

export const getRadios = async (): Promise<Radio[]> => {
  try {
    const data = await fetchSheetData(SHEETS_CONFIG.radios);
    console.log('Raw radio data:', data);
    
    return data.map(row => {
      const radio: Radio = {
        name: row[0] || '',
        logo: row[1] || '',
        genre: row[2] || '',
        streamUrl: row[3] || ''
      };
      console.log('Processed radio:', radio);
      return radio;
    });
  } catch (error) {
    console.error('Error in getRadios:', error);
    throw error;
  }
};

// Interface pour les chaînes en direct
interface DirectChannel {
  title: string;
  logo: string;
  genre: string;
  streamUrl: string;
  description?: string;
}

export const getDirectChannels = async (): Promise<DirectChannel[]> => {
  const data = await fetchSheetData(SHEETS_CONFIG.direct);
  return data.map(row => ({
    title: row[0] || '',
    logo: row[1] || '',
    genre: row[2] || '',
    streamUrl: row[3] || '',
    description: row[4] || ''
  }));
};

// Interface pour les produits
interface Product {
  title: string;
  image: string;
  merchant: string;
  price: string;
  description: string;
  buyUrl: string;
  category: string;
}

export const getProducts = async (): Promise<Product[]> => {
  const data = await fetchSheetData(SHEETS_CONFIG.shopping);
  return data.map(row => ({
    title: row[0] || '',
    image: row[1] || '',
    merchant: row[2] || '',
    price: row[3] || '',
    description: row[4] || '',
    buyUrl: row[5] || '',
    category: row[6] || 'Tous'  // Add category with default value
  }));
};

// Interface pour les films
export const getMovies = async (): Promise<Movie[]> => {
  try {
    const data = await fetchSheetData(SHEETS_CONFIG.movies);
    console.log('Raw movies data:', data);
    
    return data.map(row => ({
      title: row[0] || '',
      coverImage: row[1] || '',
      releaseDate: row[2] || '',
      duration: row[3] || '',
      description: row[4] || '',
      genre: row[5] || '',
      episodeUrl: row[6] || '',
      videoUrl: row[7] || ''
    }));
  } catch (error) {
    console.error('Error in getMovies:', error);
    throw error;
  }
};
