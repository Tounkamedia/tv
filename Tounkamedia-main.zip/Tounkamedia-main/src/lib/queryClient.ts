
import { QueryClient } from '@tanstack/react-query';

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // Données considérées comme fraîches pendant 5 minutes
      gcTime: 1000 * 60 * 30, // Garde en cache pendant 30 minutes (nouveau nom pour cacheTime)
      refetchOnWindowFocus: false,
      retry: 1,
    },
  },
});
